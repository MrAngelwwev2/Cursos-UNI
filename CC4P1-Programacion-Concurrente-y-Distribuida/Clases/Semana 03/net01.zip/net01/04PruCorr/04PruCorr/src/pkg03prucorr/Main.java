/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg03prucorr;

import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        JFrame marco = new MarcoPruebaCorreo();
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marco.setVisible(true);
    }
}
