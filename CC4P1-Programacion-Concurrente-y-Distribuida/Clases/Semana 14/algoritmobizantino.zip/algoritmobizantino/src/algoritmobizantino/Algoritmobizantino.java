package algoritmobizantino;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class General {     // Crea una ESTRUCTURA para almacenar los datos del general
    int Id;         // identificación del general
    int Traidor;    // obtiene un número aleatorio entre 0 y 10
};

public class Algoritmobizantino {
    public static List<General> Generales = new ArrayList<General>();
    
    public static void main(String[] args) {
	int traidores = 0;
        	
        Random rand = new Random();
	//srand(time(NULL));
	int n_generales = 20; // tomar la longitud del vector Generales
	
	for(int i = 0; i <= n_generales; i++){
                General general = new General();
                
		general.Id = i; 			// Asignar valor a la identificación general
		general.Traidor = rand.nextInt(10);	// Asignar un valor aleatorio al traidor	
		
		System.out.print("General " + i + ", Mensaje: ");
		
		if(general.Traidor <= 2 ){
			System.out.println("Retroceder!!!\n"); 	// Si traidor <= 2, su mensaje es retroceder
		}else{
			System.out.println("Atacar!!!\n");      // Si no eres un traidor, tu mensaje es atacar
		} 
                Generales.add(general);
	}
	
	for(int i = 0; i <= n_generales; i++){
		if(Generales.get(i).Traidor <= 2){      // Si el número entre 0 y 10 es <= 2, es un traidor.
			traidores++;
		}
	}
	
	System.out.print("\n\nNúmero de generales: " + n_generales);
	System.out.print("\nNúmero de traidores: " + traidores);
	System.out.print("\nNúmero de leales: " + (n_generales - traidores));
	
	if(n_generales >= (3*traidores) + 1 ){ 		// Marque 3 * n + 1
            System.out.println("\n¡Mensaje validado! Atacar");
	} else {
            System.out.println("\n¡Mensaje no validado!");
	}
    }
}